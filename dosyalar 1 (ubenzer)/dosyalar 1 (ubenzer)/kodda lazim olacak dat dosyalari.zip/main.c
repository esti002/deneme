#include <stdio.h>
#include <stdlib.h>

#define MIN_URUN_KODU 0
#define MAX_URUN_KODU 1000


struct STOK {
    int urun_kodu;
    char urun_adi[15];
    int stok_miktari;
    float birim_fiyati;
};

void beklet() {
    /* Bu fonksiyonun tek amaci kullaniciyi bir tusa basana kadar
       bekletmek, ve sonra ekrani silmektir.                      */
    printf("\nDevam etmek icin bir tusa basin.");
    getche();
    system ("cls");
    return 0;
}

int urun_bilgileri (FILE *fp, int urun_kodu, int tumu, int stok_limit) {

    /* Eger urun varsa bilgilerinigosterir, yoksa -1 d�nd�r�r. */
    struct STOK urun;

    fseek(fp,0,0);
    while(!feof(fp)) {
        fscanf(fp, "%d %s %d %f\n",&urun.urun_kodu, urun.urun_adi,&urun.stok_miktari,&urun.birim_fiyati);

        if ((tumu == 0 && urun.urun_kodu == urun_kodu) || tumu == 1 && (stok_limit == -1 || stok_limit >= urun.stok_miktari)) {
            system ("cls");
            printf("*** Urun bilgileri ***\n");
            printf("Urun kodu: %d \n",urun.urun_kodu);
            printf("Urun adi: %s \n",urun.urun_adi);
            printf("Stok miktari: %d \n",urun.stok_miktari);
            printf("Birim fiyati: %.2f \n\n",urun.birim_fiyati);
            beklet();
            if (tumu == 0) {
                return 0;
            }
        }
    }

    return -1;
}

void urun_ara(FILE *fp, char *metin) {

    int buldum;
    int denetlenenharf;
    struct STOK durum;

    fseek(fp,0,0);
    while(!feof(fp)) {
        fscanf(fp, "%d %s %d %f\n",&durum.urun_kodu, durum.urun_adi,&durum.stok_miktari,&durum.birim_fiyati);

        denetlenenharf = 0;
        buldum = 1;

        for(;;) {

            if (durum.urun_adi[denetlenenharf] != metin[denetlenenharf]) {
                buldum = 0;
                break;
            }

            if (durum.urun_adi[denetlenenharf] == NULL && metin[denetlenenharf + 1] != NULL) {
                buldum = 0;
                break;
            }

            if (metin[denetlenenharf + 1] == NULL) {
                break;
            }

            denetlenenharf++;
        }

        if (buldum == 1) {

            system("cls");
            printf("Arama Sonuclari\n");
            printf("---------------\n\n");
            printf("Urun kodu: %d\n", durum.urun_kodu);
            printf("Urun adi: %s\n",durum.urun_adi);
            printf("Stok miktari: %d\n\n",durum.stok_miktari);
            printf("Birim fiyati: %.2f\n",durum.birim_fiyati);

            beklet();
        }
    }

    system("cls");
    printf("Arama tamamlandi. :)\n");

    beklet();

}

int urun_var_mi(FILE *fp, int urun_kodu) {

    struct STOK urun;
    fseek(fp,0,0);
    while(!feof(fp)) {
        fscanf(fp, "%d %s %d %f\n",&urun.urun_kodu, urun.urun_adi,&urun.stok_miktari,&urun.birim_fiyati);

        if (urun_kodu == urun.urun_kodu) {
            return 0;
        }
    }

    return -1;
}

int toplu_guncelle(FILE *fp, FILE *fp2, FILE *fp3) {

    int urun_kodu;
    float urun_fiyat;
    float yeni_urun_fiyat;
    struct STOK durum;

    fseek(fp,0,0);
    while (!feof(fp)) {
        fscanf(fp, "%d %s %d %f\n",&durum.urun_kodu, durum.urun_adi,&durum.stok_miktari,&durum.birim_fiyati);

        yeni_urun_fiyat = durum.birim_fiyati;

        fseek(fp2,0,0);
        while(!feof(fp2)) {
            fscanf(fp2,"%d %f\n",&urun_kodu,&urun_fiyat);
            if (urun_kodu == durum.urun_kodu) {
                yeni_urun_fiyat = urun_fiyat;
            }
        }

        fprintf(fp3,"%d %s %d %.2f\n",durum.urun_kodu, durum.urun_adi,durum.stok_miktari,yeni_urun_fiyat);
    }

    fclose(fp);
    fclose(fp2);
    fclose(fp3);

    remove("urunler.dat");
    rename("gecici.tmp","urunler.dat");

    if((fp=fopen("urunler.dat","r")) == NULL) {
        return -1;
    }

    return 0;

}

int stok_guncelle(FILE *fp, FILE *fp2, FILE *fp3) {

    int urun_kodu;
    int urun_stok;
    struct STOK durum;

    fseek(fp,0,0);
    while (!feof(fp)) {
        fscanf(fp, "%d %s %d %f\n",&durum.urun_kodu, durum.urun_adi,&durum.stok_miktari,&durum.birim_fiyati);
        fseek(fp2,0,0);
        while(!feof(fp2)) {
            fscanf(fp2,"%d %d\n",&urun_kodu,&urun_stok);
            if (urun_kodu == durum.urun_kodu) {
                durum.stok_miktari = durum.stok_miktari + urun_stok;
            }
        }

        fprintf(fp3,"%d %s %d %.2f\n",durum.urun_kodu, durum.urun_adi,durum.stok_miktari,durum.birim_fiyati);
    }

    fclose(fp);
    fclose(fp2);
    fclose(fp3);

    remove("urunler.dat");
    rename("gecici.tmp","urunler.dat");

    if((fp=fopen("urunler.dat","r")) == NULL) {
        return -1;
    }

    return 0;

}

int urun_guncelle(FILE *fp, FILE *gecici,int urun_kodu) {

    struct STOK urun;
    int yeni_stok = -1;
    float yeni_fiyat = -1;
    int sayac;

    while (yeni_stok < 0) {
        system("cls");
        printf("Yeni stok miktarini giriniz: ");
        scanf("%d",&yeni_stok);
    }

    while (yeni_fiyat < 0) {
        system("cls");
        printf("Yeni fiyati giriniz: (ondalik icin . kullanilir) ");
        scanf("%f",&yeni_fiyat);
    }

    fseek(fp,0,0);

    while(!feof(fp)) {

        for (sayac=0;sayac<15;sayac++) {
            urun.urun_adi[sayac] = NULL;
        }

        fscanf(fp, "%d %s %d %f\n",&urun.urun_kodu, urun.urun_adi,&urun.stok_miktari,&urun.birim_fiyati);

        if (urun.urun_kodu != urun_kodu) {
            fprintf(gecici,"%d %s %d %.2f\n",urun.urun_kodu, urun.urun_adi,urun.stok_miktari,urun.birim_fiyati);
        } else {
            fprintf(gecici,"%d %s %d %.2f\n",urun.urun_kodu, urun.urun_adi,yeni_stok,yeni_fiyat);
        }
    }

    fclose(gecici);
    fclose(fp);
    remove("urunler.dat");
    rename("gecici.tmp","urunler.dat");

    if((fp=fopen("urunler.dat","r")) == NULL) {
        return -1;
    }

    return 0;

}

int main() {
    printf("Umut Benzer\n");
	printf("Urun Raporlama Yazilimi 2 (beta)\n");
	printf("http://www.ubenzer.com\n\n");

    /* Dosyayy bir nedenden dolayy a�amama durumunda hata mesajy verme de dahil olmak �zere dosya a�ma i?lemi BASLANGICI */
    FILE *fp;
    FILE *fp2;
    FILE *fp3;

    if((fp=fopen("urunler.dat","r")) == NULL) {
        printf ("Hata: urunler.dat dosyasi acilamadi. Gidiyorum ben.");
        return 0;
    }

    int sag_serbest=-1;
    char secenek;
    int girdi;
    char ara_urun_adi[16];
    int sayac;

    while (sag_serbest==-1) {

        /* menu BASLANGICI */
        printf("*** Menu *** \n\n");
        printf("1. Urun bilgisi sorgulama \n");
        printf("2. Urun arama \n");
        printf("3. Tum urunleri listeleme \n");
        printf("4. Stok miktarina gore urun listeleme \n");
        printf("5. Urun bilgisi guncelleme \n");
        printf("6. Toplu urun fiyati guncelleme \n");
        printf("7. Toplu stok miktari guncelleme \n");
        printf("8. Cikis \n\n");

        printf("Lutfen istediginiz islemin numarasini giriniz. ");
        /*menu BITIMI */

        secenek=getche();
        system ("cls");

        switch(secenek) {
            case 49: //1
                girdi = MIN_URUN_KODU - 1;
                while(girdi < MIN_URUN_KODU || girdi > MAX_URUN_KODU) {
                    system("cls");
                    printf("Urun kodunu giriniz: ");
                    scanf("%d",&girdi);
                }
                if (urun_bilgileri(fp,girdi,0,-1) == -1) {
                    printf("Boyle bir urun yok.");
                    beklet();
                }
                break;
            case 50: //2
                for (sayac=0;sayac<16;sayac++) {
                    ara_urun_adi[sayac] = NULL; /* Once sifirlayalim, babalara gelmeyelim sonra. */
                }
                system("cls");
                printf("Aranacak urunun ilk harflerinden bir kacini giriniz:\n");
                printf("(kucuk harf, tek kelime)\n");
                scanf("%s",ara_urun_adi);
                urun_ara(fp,ara_urun_adi);

                break;
            case 51: //3
                urun_bilgileri(fp,girdi,1,-1);
                system("cls");
                printf("Islem tamam. :)");
                beklet();
                break;
            case 52: //4
                girdi = -1;
                while(girdi < 0) {
                    system("cls");
                    printf("Kactan kucuk olsun istiyorsunuz? ");
                    scanf("%d",&girdi);
                }
                urun_bilgileri(fp,-1,1,girdi);
                system("cls");
                printf("Islem tamam. :)");
                beklet();
                break;
            case 53: //5
                girdi = MIN_URUN_KODU - 1;
                while(girdi < MIN_URUN_KODU || girdi > MAX_URUN_KODU) {
                    system("cls");
                    printf("Urun kodunu giriniz: ");
                    scanf("%d",&girdi);
                }

                if (urun_var_mi(fp,girdi) == -1) {
                    printf("Boyle bir urun yok.");
                    beklet();
                } else {
                    if((fp2=fopen("gecici.tmp","w")) == NULL) {
                        printf ("Hata: gecici dosya yaratilamadi.");
                        return 0;
                    }
                    if (urun_guncelle(fp,fp2,girdi) == -1) {
                        printf("Bir hata olustu, gidiyorum ben.");
                        return 0;
                    } else {
                        system("cls");
                        printf("Islem tamam. :)");
                        beklet();
                    }
                }
                break;
            case 54: //6
                system("cls");
                printf("fiyati_degisenler.dat doyasindan toplu guncellemeye\nbaslamak icin bir tusa basin.\n");
                getche();

                if((fp2=fopen("fiyati_degisenler.dat","r")) == NULL) {
                    system ("cls");
                    printf ("fiyati_degisenler.dat okunamadi.\n Ana menuye donuyorum.\n");
                    beklet();
                } else {
                    if((fp3=fopen("gecici.tmp","w")) == NULL) {
                        printf ("Hata: gecici dosya yaratilamadi.");
                        return 0;
                    }
                    if (toplu_guncelle(fp,fp2,fp3) == -1) {
                        printf("Bir hata olustu, gidiyorum ben.");
                        return 0;
                    } else {
                        system("cls");
                        printf("Islem tamam. :)");
                        beklet();
                    }
                }
                break;
            case 55: //7
                system("cls");
                printf("stok_giris_cikis.dat doyasindan toplu guncellemeye\nbaslamak icin bir tusa basin.\n");
                getche();

                if((fp2=fopen("stok_giris_cikis.dat","r")) == NULL) {
                    system ("cls");
                    printf ("stok_giris_cikis.dat okunamadi.\n Ana menuye donuyorum.\n");
                    beklet();
                } else {
                    if((fp3=fopen("gecici.tmp","w")) == NULL) {
                        printf ("Hata: gecici dosya yaratilamadi.");
                        return 0;
                    }
                    if (stok_guncelle(fp,fp2,fp3) == -1) {
                        printf("Bir hata olustu, gidiyorum ben.");
                        return 0;
                    } else {
                        system("cls");
                        printf("Islem tamam. :)");
                        beklet();
                    }
                }
                break;
            case 56: //8
                /* E e H h ve disinda girdi kabul etmeyen cikmak istiyor musunuz sorusu BASLANGICI */
                do {
                    printf ("\nCidden cikmak istiyor musunuz? (E/H) ");
                    secenek = getche();
                    if (secenek == 'E' || secenek == 'e') {
                        sag_serbest = 0;
                        secenek = 'H';
                    }
                } while (secenek != 'H' && secenek != 'h');
                /* E e H h ve disinda girdi kabul etmeyen cikmak istiyor musunuz sorusu SONU */
                system ("cls");
                break;
            default:
                /* Elleri yanlis tusa basan kullanicilar icin yazilan bolum BASLANGICI */
                printf("Bir zahmet 1'den 8'e kadar bir secim yapin.");
                beklet();
                /* Elleri yanlis tusa basan kullanicilar icin yazilan bolum SONU */
                break;
        }
    }

    printf("O halde hoscakalin. :)\n\n\n");
    return 0;
}
